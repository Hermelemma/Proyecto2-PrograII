package General;

/**
 * Clase para asignar los tipos de vehiculos
 * @author Emmanuel Herrera
 * @version 1.0
 */
public enum EnumVehiculo {
    CAMION, CARRO, MOTO;
}
