package General;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * Esta clase contiene main principal
 * @author Emmanuel Herrera
 * @version 1.0
 */
public class Ejecutar extends Application{

    /**
     * Metodo que levanta la primera escena de la interfaz
     * @param primaryStage Stage recibe un parametro para levantar el escenario
     **/
    @Override
    public void start(Stage primaryStage) throws Exception {
        Pane root = (Pane) FXMLLoader.load(getClass().getResource("/vista/Datos.fxml"));
        primaryStage.setTitle("Establecer Datos de Estacionamiento");
        Scene scene = new Scene(root, 600,400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * En este metodo se compila el codigo
     */
    public static void main(String[] args) {
        launch(args);
    }

}