package General;

import java.util.Date;

/**
 *Esta clase hereda de la clase Vehiculo y tiene funcionalidad util para el uso del programa
 * @author Emmanuel Herrera
 * @version 1.0.0
 **/
public class Automovil extends Vehiculo{


    public Automovil(){

    }

    /**
     * Este metodo es un constructor con parametros
     * @param lugar numero entero necesario para mandar como parametro al constructor de la clase padre
     * @param placa String necesario para mandar como parametro al constructor de la clase padre
     * @param horaEntrada tipo Date necesario para mandar como parametro al constructor de la clase padre
     * @param enumVehiculo double necesario para mandar como parametro al constructor de la clase padre
     * @param segundos tipo entero necesario para mandar como parametro al constructor de la clase padre
     **/
    public Automovil(int lugar, String placa, Date horaEntrada, EnumVehiculo enumVehiculo, int segundos) {
        super(lugar, placa, horaEntrada, enumVehiculo, segundos);
    }

    /**
     * Metodo que establece el total a pagar para los automoviles que salen del estacionamiento
     * @param tiempo entero necesario para hacer un calculo y devolver un double
     * @param tarifa double necesario para hacer un calculo y devolver otro double
     * @return double devuelve el total a pagar para los automoviles
     **/
    public double montoTotalAutomovil(int tiempo, double tarifa){

        double montoTotal = tiempo*tarifa;

        return montoTotal;
    }

}
