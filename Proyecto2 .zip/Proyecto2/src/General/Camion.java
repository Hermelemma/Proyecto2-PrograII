package General;


import java.util.Date;

/**
 *Esta clase hereda de la clase Vehiculo y tiene funcionalidad util para el uso del programa
 * @author Emmanuel Herrera
 * @version 1.0.0
 **/
public class Camion extends Vehiculo{

    /**
     * Este metodo es un constructor vacio
     **/
    public Camion(){

    }

    /**
     * Este metodo es un constructor con parametros
     * @param lugar tipo entero necesario para mandar como parametro al constructor de la clase padre
     * @param placa String necesario para mandar como parametro al constructor de la clase padre
     * @param horaEntrada tipo Date necesario para mandar como parametro al constructor de la clase padre
     * @param enumVehiculo tipo EnumVehiculo necesario para mandar como parametro al constructor de la clase padre
     * @param segundos tipo entero necesario para mandar como parametro al constructor de la clase padre
     **/
    public Camion(int lugar, String placa, Date horaEntrada, EnumVehiculo enumVehiculo, int segundos) {
        super(lugar, placa, horaEntrada, enumVehiculo, segundos);
    }

    /**
     * Metodo que establece el total a pagar para los camiones que salen del estacionamiento
     * @param periodos entero necesario para hacer un calculo y devolver un double
     * @return double devuelve el total a pagar para los camiones
     **/
    public double montoTotalCamion(int periodos){
        double montoTotal =0;
        if(periodos == 1){
            montoTotal = 17.5;
        }else{
            montoTotal = ((17.5*periodos)+(5*(periodos-1))-17.5);
        }
        return montoTotal;
    }
}
