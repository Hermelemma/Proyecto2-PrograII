package General;

import java.util.Date;

/**
 * Esta es la clase padre de los tipos de vehiculos
 * @author Emmanuel Herrera
 * @version 1.0.0
 */
public class Vehiculo {

    private int lugar;
    private String placa;
    private Date horaEntrada;
    private EnumVehiculo enumVehiculo;
    private int segundos;

    /**
     * Este metodo es un constructor vacio
     */
    public Vehiculo(){}

    /**
     * Este metodo es un constructor con parametros
     * @param lugar numero entero necesario para ingresar el valor de este atributo
     * @param placa String necesario para ingresar el valor de este atributo
     * @param horaEntrada tipo Date necesario para ingresar el valor de este atributo
     * @param enumVehiculo tipo EnumVehiculo necesario para ingresar el valor de este atributo
     * @param segundos tipo entero necesario para mandar como parametro al constructor de la clase padre
     **/
    public Vehiculo(int lugar, String placa, Date horaEntrada, EnumVehiculo enumVehiculo, int segundos) {
        this.lugar = lugar;
        this.placa = placa;
        this.horaEntrada = horaEntrada;
        this.enumVehiculo = enumVehiculo;
        this.segundos = segundos;
    }

    /**
     * Metodo para obtener el valor de un atributo
     * @return String devuelve un string con el valor del atributo
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * Metodo para obtener el valor de un atributo
     * @return entero devuelve un entero con el valor del atributo
     */
    public int getSegundos() {
        return segundos;
    }

    /**
     * Metodo para obtener el valor de un atributo
     * @return Date devuelve una fecha con el valor del atributo
     */
    public Date getHoraEntrada() {
        return horaEntrada;
    }
}