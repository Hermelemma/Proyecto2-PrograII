package General;

import javafx.scene.control.Button;
import javafx.stage.Stage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.PDPage;
import java.time.LocalTime;
import java.util.Date;

/**
 * Clase que contiene funcionalidad util para el uso del programa
 * @author Emmanuel Herrera
 * @version 1.0
 */
public class Funciones {

    /**
     * Este es un metodo que se utiliza para salir de una escena
     * @param boton Boton que se utiliza para salir de una interfaz
     */
    public void salir(Button boton){
        Stage stage = (Stage) boton.getScene().getWindow();
        stage.close();
    }

    /**
     * Este es un metodo que se utiliza para generar un ticket
     * @param noEstacionamiento entero que se utiliza para imprimir en la factura el lugar de estacionamiento que se le asigno
     * @param placa String que se utiliza para valdiar que vehiculo saldra del estacionamiento
     * @param fecha Date que se utiliza para imprimir en la factura la hora de entrada
     * @throws Exception puede arrojar una excepcion
     */
    public void ticket(int noEstacionamiento, String placa, Date fecha) throws Exception{
        PDDocument documento = new PDDocument();
        PDPage pagina = new PDPage(PDRectangle.A5);
        documento.addPage(pagina);
        PDPageContentStream contenido = new PDPageContentStream(documento, pagina);

        String contS = Integer.toString(noEstacionamiento);

        for (int i = 1; i <= 4; i++) {
            contenido.beginText();
            contenido.setFont(PDType1Font.TIMES_BOLD, 12);
            if (i == 1) {
                contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                contenido.showText(":TICKET:");
            }
            if (i == 2 && contS.length() == 1) {
                contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                contenido.showText("Estacionamiento ------------------------ 00" + noEstacionamiento);
            }
            if (i == 2 && contS.length() == 2) {
                contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                contenido.showText("Estacionamiento ------------------------ 0" + noEstacionamiento);
            }
            if (i == 2 && contS.length() == 3) {
                contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                contenido.showText("Estacionamiento ------------------------ " + noEstacionamiento);
            }
            if (i == 3) {
                contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                contenido.showText("Placa ------------------------ " + placa);
            }
            if (i == 4) {
                contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                contenido.showText("Entrada ------------------------ " + fecha);
            }

            contenido.endText();
        }
        contenido.close();

        documento.save("C:/Ticket/ticket.pdf");
    }

    /**
     * Este es un metodo que se utiliza para generar una factura
     * @param placa String que se utiliza para valdiar que vehiculo saldra del estacionamiento
     * @param NIT String que se utiliza para imprimir en la factura el nit del cliente
     * @param entrada Date que se utiliza para imprimir en la factura la hora de entrada
     * @param salida Date que se utiliza para imprimir en la factura la hora de salida
     * @param monto double que se utiliza para imprimir en la factura el monto inicial a pagar
     * @param descuento double que se utiliza para imprimir en la factura los descuentos realizados
     * @param recargo double que se utiliza para imprimir en la factura los recargos realizados
     * @param montoTotal double que se utiliza para imprimir en la factura el monto total a pagar
     * @throws Exception puede arrojar una excepcion
     */
    public void factura(String placa, String NIT, Date entrada, Date salida, double monto, double descuento, double recargo, double montoTotal) throws Exception{
        if(placa.charAt(0)=='M'){
            PDDocument documento = new PDDocument();
            PDPage pagina = new PDPage(PDRectangle.A5);
            documento.addPage(pagina);
            PDPageContentStream contenido = new PDPageContentStream(documento, pagina);

            for (int i = 1; i <= 8; i++) {
                contenido.beginText();
                contenido.setFont(PDType1Font.TIMES_BOLD, 12);
                if (i == 1) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText(":FACTURA:");
                }
                if (i == 2) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("NIT --------------------------- " + NIT);
                }
                if (i == 3) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Fecha/Hora Entrada --------------------------- " + entrada);
                }
                if (i == 4) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Fecha/Hora Salida --------------------------- " + salida);
                }
                if (i == 5) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Tarifa ---------------------------  " + monto);
                }
                if (i == 6) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Descuento de --------------------------- " + descuento);
                }
                if (i == 7) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Recargo de --------------------------- " + recargo);
                }
                if (i == 8) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Total --------------------------- " + montoTotal);
                }

                contenido.endText();
            }
            contenido.close();

            documento.save("C:/Facturas/factura.pdf");
        }

        if(placa.charAt(0)=='P'){
            PDDocument documento = new PDDocument();
            PDPage pagina = new PDPage(PDRectangle.A5);
            documento.addPage(pagina);
            PDPageContentStream contenido = new PDPageContentStream(documento, pagina);

            for (int i = 1; i <= 8; i++) {
                contenido.beginText();
                contenido.setFont(PDType1Font.TIMES_BOLD, 12);
                if (i == 1) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText(":FACTURA:");
                }
                if (i == 2) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("NIT --------------------------- " + NIT);
                }
                if (i == 3) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Fecha/Hora Entrada --------------------------- " + entrada);
                }
                if (i == 4) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Fecha/Hora Salida --------------------------- " + salida);
                }
                if (i == 5) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Tarifa ---------------------------  " + monto);
                }
                if (i == 6) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Descuento de --------------------------- " + descuento);
                }
                if (i == 7) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Recargo de --------------------------- " + recargo);
                }
                if (i == 8) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Total --------------------------- " + montoTotal);
                }

                contenido.endText();
            }
            contenido.close();

            documento.save("C:/Facturas/factura.pdf");
        }

        if(placa.charAt(0)=='C'){
            PDDocument documento = new PDDocument();
            PDPage pagina = new PDPage(PDRectangle.A5);
            documento.addPage(pagina);
            PDPageContentStream contenido = new PDPageContentStream(documento, pagina);

            for (int i = 1; i <= 8; i++) {
                contenido.beginText();
                contenido.setFont(PDType1Font.TIMES_BOLD, 12);
                if (i == 1) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText(":FACTURA:");
                }
                if (i == 2) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("NIT --------------------------- " + NIT);
                }
                if (i == 3) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Fecha/Hora Entrada --------------------------- " + entrada);
                }
                if (i == 4) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Fecha/Hora Salida --------------------------- " + salida);
                }
                if (i == 5) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Tarifa ---------------------------  " + monto);
                }
                if (i == 6) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Descuento de --------------------------- " + descuento);
                }
                if (i == 7) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Recargo de --------------------------- " + recargo);
                }
                if (i == 8) {
                    contenido.newLineAtOffset(20, pagina.getMediaBox().getHeight() - (52 * i));
                    contenido.showText("Total --------------------------- " + montoTotal);
                }

                contenido.endText();
            }
            contenido.close();

            documento.save("C:/Facturas/factura.pdf");
        }


    }

    /**
     * Este es un metodo que se utiliza para hacer el calculo de los segundos que estuvo en el estacionamiento
     * @param tiempo Localtime que se utiliza para realizar el calculo de los segundos del dia
     * @return entero que se utiliza para devolver los segundos transcurridos en el dia
     */
    public int segundos(LocalTime tiempo){
        String hora = tiempo + "";
        char min1 = hora.charAt(3);
        char min2 = hora.charAt(4);
        char seg1 = hora.charAt(6);
        char seg2 = hora.charAt(7);
        String minuto = "" + min1 + min2;
        String segundo = "" + seg1 +seg2;
        int min = Integer.parseInt(minuto);
        int seg = Integer.parseInt(segundo);
        int totalSegs = (min * 60) + seg;
        return totalSegs;
    }

}
