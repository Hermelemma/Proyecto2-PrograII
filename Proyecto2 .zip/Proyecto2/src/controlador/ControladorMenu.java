package controlador;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.control.Button;

/**
 * Esta clase es un controllador que carga las interfaces de ingresar un vehiculo y retirar un vehiculo
 * @author Emmanuel Herrera
 * @version 1.0
 */
public class ControladorMenu {

    public Button exit1;
    public Button exit2;

    /**
     * Este metodo carga la interfaz para ingresar un vehiculo
     * @param actionEvent recibe un parametro actionEvent
     * @throws Exception puede arrojar una excepcion
     */
    public void ingresarEstacionamiento(ActionEvent actionEvent) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/vista/Ingresar.fxml"));
        Pane root = (Pane) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Estacionamiento");
        stage.setScene(new Scene(root, 600, 400));
        stage.show();
    }

    /**
     * Este metodo carga la interfaz para retirar un vehiculo
     * @param actionEvent recibe un parametro actionEvent
     * @throws Exception puede arrojar una excepcion
     */
    public void retirarEstacionamiento(ActionEvent actionEvent) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/vista/Retirar.fxml"));
        Pane root = (Pane) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Estacionamiento");
        stage.setScene(new Scene(root, 600, 400));
        stage.show();
    }

}