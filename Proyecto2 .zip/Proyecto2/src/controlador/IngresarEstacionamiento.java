package controlador;

import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import java.util.ArrayList;
import java.util.Date;
import General.*;
import java.time.LocalTime;

/**
 * Esta clase es un controllador para guardar los datos ingresados desde la interfaz
 * @author Emmanuel Herrera
 * @version 1.0
 */
public class IngresarEstacionamiento {

    private int Motos;
    private int Camiones;
    private int Carros;
    public static ArrayList<Vehiculo> vehiculo = new ArrayList<>();
    public TextField placaRecibida;
    public TextField mensajeRecibido;
    Funciones fun = new Funciones();

    /**
     * Este metodo graba los datos ingresados desde la interfaz y genera un ticket
     * @param actionEvent recibe un parametro actionEvent
     */
    public void grabarPlaca(ActionEvent actionEvent){
        String placa = placaRecibida.getText();
        placaRecibida.setText("");
        Date fecha = new Date();
        boolean lleno = true;
        LocalTime HoraInicio = LocalTime.now();
        int startTime = fun.segundos(HoraInicio);
        if(placa.charAt(0) == 'P' && Carros < DatosController.estacionamientosParaAutos){
            Carros++;
            Vehiculo c = new Vehiculo(Carros, placa, fecha, EnumVehiculo.CARRO, startTime);
            lleno = false;
            vehiculo.add(c);
            try{
                fun.ticket(Carros, placa, fecha);
                mensajeRecibido.setText("¡Ticket listo!");
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
        if(placa.charAt(0) == 'M' && Motos < DatosController.estacionamientosParaMotos) {
            Motos++;
            Vehiculo m = new Vehiculo(Motos, placa, fecha, EnumVehiculo.MOTO, startTime);
            lleno = false;
            vehiculo.add(m);
            try{
                fun.ticket(Motos, placa, fecha);
                mensajeRecibido.setText("¡Ticket listo!");
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
        if(placa.charAt(0) == 'C' && Camiones < DatosController.estacionamientosParaCamiones){
            Camiones++;
            Vehiculo c = new Vehiculo(Camiones, placa, fecha, EnumVehiculo.CAMION, startTime);
            lleno = false;
            vehiculo.add(c);
            try{
                fun.ticket(Camiones, placa, fecha);
                mensajeRecibido.setText("¡Ticket listo!");
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
        if(lleno == true){
            mensajeRecibido.setText("No hay parqueos disponibles");
        }
    }

}
