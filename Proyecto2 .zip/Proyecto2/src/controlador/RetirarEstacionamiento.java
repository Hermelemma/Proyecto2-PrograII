package controlador;

import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import General.*;
import java.util.Date;
import java.time.LocalTime;

/**
 * Esta clase es un controllador para guardar los datos ingresados desde la interfaz
 * @author Emmanuel Herrera
 * @version 1.0
 */
public class RetirarEstacionamiento {

    public TextField placaRecibida;
    public TextField mensajeRecibido;
    public TextField nitRecibido;
    Funciones fun = new Funciones();
    Motocicleta motocicleta = new Motocicleta();
    Automovil auto = new Automovil();
    Camion cam = new Camion();
    public static double totalAPagar = 0;

    /**
     * Este metodo graba los datos ingresados desde la interfaz y genera una factura
     * @param actionEvent recibe un parametro actionEvent
     */
    public void grabarPlacaR(ActionEvent actionEvent) {
        String placa = placaRecibida.getText();
        placaRecibida.setText("");
        int x = 0;
        LocalTime tiempoFinal = LocalTime.now();
        int endTime = fun.segundos(tiempoFinal);

        double tarifa = DatosController.tarifa;
        if(placa.charAt(0) == 'M'){
            for(x = 0; x<IngresarEstacionamiento.vehiculo.size(); x++){
                if(placa.equals(IngresarEstacionamiento.vehiculo.get(x).getPlaca())){
                    Date dateEntrada = IngresarEstacionamiento.vehiculo.get(x).getHoraEntrada();
                    Date dateSalida = new Date();
                    String nit = nitRecibido.getText();
                    nitRecibido.setText("");
                    int startTime = IngresarEstacionamiento.vehiculo.get(x).getSegundos();
                    int totalTime = endTime - startTime;
                    double monto = totalTime*tarifa;
                    double descuento = monto * 0.10;
                    double recargo = 0;
                    totalAPagar = motocicleta.montoTotalMoto(totalTime, tarifa);
                    IngresarEstacionamiento.vehiculo.remove(x);
                    try{
                        fun.factura(placa, nit, dateEntrada, dateSalida, monto, descuento, recargo, totalAPagar);
                        mensajeRecibido.setText("Factura lista");
                    }catch (Exception e){
                        System.out.println(e.getMessage());
                    }
                }
            }
        }
        if(placa.charAt(0) == 'P'){
            for(x = 0; x<IngresarEstacionamiento.vehiculo.size(); x++){
                if(placa.equals(IngresarEstacionamiento.vehiculo.get(x).getPlaca())){
                    Date dateEntrada = IngresarEstacionamiento.vehiculo.get(x).getHoraEntrada();
                    Date dateSalida = new Date();
                    String nit = nitRecibido.getText();
                    nitRecibido.setText("");
                    int startTime = IngresarEstacionamiento.vehiculo.get(x).getSegundos();
                    int totalTime = endTime - startTime;
                    double monto = totalTime*tarifa;
                    double descuento = 0;
                    double recargo = 0;
                    totalAPagar = auto.montoTotalAutomovil(totalTime, tarifa);
                    IngresarEstacionamiento.vehiculo.remove(x);
                    try{
                        fun.factura(placa, nit, dateEntrada, dateSalida, monto, descuento, recargo, totalAPagar);
                        mensajeRecibido.setText("Factura lista");
                    }catch (Exception e){
                        System.out.println(e.getMessage());
                    }
                }
            }
        }
        if(placa.charAt(0) == 'C'){
            for(x = 0; x<IngresarEstacionamiento.vehiculo.size(); x++){
                if(placa.equals(IngresarEstacionamiento.vehiculo.get(x).getPlaca())){
                    Date dateEntrada = IngresarEstacionamiento.vehiculo.get(x).getHoraEntrada();
                    Date dateSalida = new Date();
                    String nit = nitRecibido.getText();
                    nitRecibido.setText("");
                    int startTime = IngresarEstacionamiento.vehiculo.get(x).getSegundos();
                    int totalTime = endTime - startTime;

                    double monto = 17.5;
                    double descuento = 0;
                    double recargo = 0;
                    int periodos = 0;
                    if(totalTime > 0 && totalTime<= 45){
                        recargo = 0;
                        periodos = 1;
                    }
                    if(totalTime > 45 && totalTime<=90){
                        recargo = 5;
                        periodos = 2;
                    }
                    if(totalTime > 90 && totalTime<=135){
                        recargo = 10;
                        periodos = 3;
                    }
                    if(totalTime > 135 && totalTime<=180){
                        recargo = 15;
                        periodos = 4;
                    }
                    if(totalTime > 180 && totalTime<=225){
                        recargo = 20;
                        periodos = 5;
                    }
                    if(totalTime > 225 && totalTime<=270){
                        recargo = 25;
                        periodos = 6;
                    }
                    if(totalTime > 270 && totalTime<=315){
                        recargo = 30;
                        periodos = 7;
                    }
                    if(totalTime > 315 && totalTime<=360){
                        recargo = 35;
                        periodos = 8;
                    }
                    if(totalTime > 360 && totalTime<=405){
                        recargo = 40;
                        periodos = 9;
                    }
                    if(totalTime > 405 && totalTime<=450){
                        recargo = 45;
                        periodos = 10;
                    }
                    if(totalTime > 450 && totalTime<=495){
                        recargo = 50;
                        periodos = 11;
                    }
                    if(totalTime > 495 && totalTime<=540){
                        recargo = 55;
                        periodos = 12;
                    }
                    if(totalTime > 540 && totalTime<=585){
                        recargo = 60;
                        periodos = 13;
                    }
                    totalAPagar = cam.montoTotalCamion(periodos);
                    IngresarEstacionamiento.vehiculo.remove(x);
                    try{
                        fun.factura(placa, nit, dateEntrada, dateSalida, monto, descuento, recargo, totalAPagar);
                        mensajeRecibido.setText("Factura lista");
                    }catch (Exception e){
                        System.out.println(e.getMessage());
                    }
                }
            }
        }
    }
}
