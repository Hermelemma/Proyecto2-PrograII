package controlador;

import javafx.event.ActionEvent;
import javafx.scene.control.TextField;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import General.*;


/**
 * Esta clase es un controllador para guardar los datos ingresados de la interfaz y cargar el menu
 * @author Emmanuel Herrera
 * @version 1.0
 */
public class DatosController {

    public TextField noEstacionamientoMotos;
    public TextField noEstacionamientoCarros;
    public TextField noEstacionamientoCamiones;
    public TextField cantTarifa;
    public TextField mensaje;
    public Button cerrar;
    public static int estacionamientosParaMotos;
    public static int estacionamientosParaAutos;
    public static int estacionamientosParaCamiones;
    public static double tarifa;
    Funciones fun = new Funciones();


    /**
     * Este metodo graba los datos ingresados desde la interfaz
     * @param actionEvent recibe un parametro actionEvent
     */
    public void grabarDatos(ActionEvent actionEvent){
        int esMo = Integer.parseInt(noEstacionamientoMotos.getText());
        estacionamientosParaMotos = esMo;
        int esCar = Integer.parseInt(noEstacionamientoCarros.getText());
        estacionamientosParaAutos = esCar;
        int esCam = Integer.parseInt(noEstacionamientoCamiones.getText());
        estacionamientosParaCamiones = esCam;
        double ctarifa = Double.parseDouble(cantTarifa.getText());
        tarifa = ctarifa;
        noEstacionamientoMotos.setText("");
        noEstacionamientoCarros.setText("");
        noEstacionamientoCamiones.setText("");
        cantTarifa.setText("");
        mensaje.setText("Informacion grabada");
    }

    /**
     * Este metodo contruye una nueva interfaz
     * @param actionEvent recibe un parametro actionEvent
     * @throws Exception puede arrojar una excepcion
     */
    public void MenuPrincipal(ActionEvent actionEvent) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/vista/Menu.fxml"));
        Pane root = (Pane) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Estacionamiento");
        stage.setScene(new Scene(root, 600, 400));
        stage.show();
        fun.salir(cerrar);
    }

}